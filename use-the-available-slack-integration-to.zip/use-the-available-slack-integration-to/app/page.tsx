"use client";

import { useMemo, useState } from "react";

const dailySpends = ["Food", "Transport", "Chai/snacks", "Printing"];
const categories = [
  ["Hostel/Rent", 7000],
  ["Mess/Food", 4500],
  ["Stationery & Books", 900],
  ["Printing & Projects", 1200],
  ["Transport", 1800],
  ["Phone & Subscriptions", 650],
  ["Personal Spending", 2500],
  ["Savings/Goals", 1500],
] as const;

const expenses = [
  ["Auto to college", "Transport", 220],
  ["Swiggy dinner", "Mess/Food", 180],
  ["Lab manual print", "Printing & Projects", 140],
] as const;

export default function Home() {
  const [income, setIncome] = useState(22000);
  const [irregular, setIrregular] = useState(true);
  const [selected, setSelected] = useState(["Food", "Transport", "Printing"]);
  const [split, setSplit] = useState(false);
  const [quick, setQuick] = useState("220 auto");

  const budgetTotal = useMemo(
    () => categories.reduce((sum, item) => sum + item[1], 0),
    [],
  );
  const spent = 13720;
  const left = income - spent;
  const daysLeft = 12;

  return (
    <main className="min-h-screen bg-[#f6f4ef] text-[#151515]">
      <section className="mx-auto grid max-w-7xl gap-5 px-4 py-5 lg:grid-cols-[360px_1fr_340px] lg:px-6">
        <aside className="rounded-[28px] bg-[#17201c] p-5 text-white shadow-2xl shadow-black/10 lg:min-h-[calc(100vh-40px)]">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-[#b9d8c8]">HostelWallet</p>
              <h1 className="mt-1 text-4xl font-black leading-none">
                No spreadsheets. Just clarity.
              </h1>
            </div>
            <span className="grid size-12 place-items-center rounded-2xl bg-[#d8ff69] text-xl text-[#17201c]">
              ₹
            </span>
          </div>

          <div className="mt-7 rounded-3xl bg-white/10 p-4">
            <p className="text-sm text-[#b9d8c8]">Sign up</p>
            <label className="mt-3 block text-xs uppercase tracking-widest text-white/60">
              Phone or email
            </label>
            <input
              className="mt-2 w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 outline-none"
              defaultValue="+91 98765 43210"
              aria-label="Phone or email"
            />
            <button className="mt-3 w-full rounded-2xl bg-[#d8ff69] px-4 py-3 font-bold text-[#17201c]">
              Continue
            </button>
            <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <button className="rounded-2xl bg-white/10 py-3">Google</button>
              <button className="rounded-2xl bg-white/10 py-3">Apple</button>
            </div>
          </div>

          <div className="mt-5 rounded-3xl bg-[#ffb951] p-4 text-[#241503]">
            <p className="text-sm font-bold">3-minute MVP flow</p>
            <p className="mt-2 text-sm">
              Sign up, set allowance, adjust budgets, log one expense, and
              settle with a roommate.
            </p>
          </div>
        </aside>

        <section className="space-y-5">
          <div className="rounded-[28px] bg-white p-5 shadow-xl shadow-black/5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-[#597366]">
                  Income setup
                </p>
                <h2 className="mt-1 text-2xl font-black">
                  How much do you get monthly?
                </h2>
              </div>
              <button
                onClick={() => setIrregular(!irregular)}
                className={`rounded-full px-4 py-2 text-sm font-bold ${
                  irregular ? "bg-[#17201c] text-white" : "bg-[#eef0e8]"
                }`}
              >
                Irregular income
              </button>
            </div>
            <div className="mt-5 grid gap-4 md:grid-cols-[1fr_1.4fr]">
              <label className="rounded-3xl bg-[#f6f4ef] p-4">
                <span className="text-sm text-[#637166]">Monthly allowance</span>
                <input
                  type="number"
                  min={0}
                  step={500}
                  value={income}
                  onChange={(event) => setIncome(Number(event.target.value))}
                  className="mt-2 w-full bg-transparent text-4xl font-black outline-none"
                  aria-label="Monthly allowance"
                />
              </label>
              <div className="rounded-3xl bg-[#eef6ff] p-4">
                <p className="text-sm font-bold text-[#31556f]">
                  What do you pay for daily?
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {dailySpends.map((item) => (
                    <button
                      key={item}
                      onClick={() =>
                        setSelected((current) =>
                          current.includes(item)
                            ? current.filter((entry) => entry !== item)
                            : [...current, item],
                        )
                      }
                      className={`rounded-full px-4 py-2 text-sm font-bold ${
                        selected.includes(item)
                          ? "bg-[#256cdd] text-white"
                          : "bg-white text-[#31556f]"
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-[28px] bg-white p-5 shadow-xl shadow-black/5">
            <div className="flex flex-wrap justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-[#597366]">
                  Category setup
                </p>
                <h2 className="mt-1 text-2xl font-black">Smart starter budget</h2>
              </div>
              <div className="rounded-2xl bg-[#f6f4ef] px-4 py-2 text-sm">
                <b>₹{budgetTotal.toLocaleString("en-IN")}</b> allocated of ₹
                {income.toLocaleString("en-IN")}
              </div>
            </div>
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {categories.map(([name, amount]) => (
                <div key={name} className="rounded-3xl border border-[#ece8db] p-4">
                  <div className="flex justify-between gap-3 text-sm">
                    <span className="font-bold">{name}</span>
                    <span>₹{amount.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="mt-3 h-2 rounded-full bg-[#ebe7db]">
                    <div
                      className="h-2 rounded-full bg-[#2f8c67]"
                      style={{ width: `${Math.min((amount / income) * 160, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <button className="mt-4 rounded-2xl border border-dashed border-[#9ea894] px-4 py-3 font-bold">
              + Add Custom Category
            </button>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            <div className="rounded-[28px] bg-[#17201c] p-5 text-white">
              <p className="text-sm text-[#b9d8c8]">Home dashboard</p>
              <h2 className="mt-1 text-2xl font-black">₹{left.toLocaleString("en-IN")} left</h2>
              <p className="mt-1 text-sm text-white/70">{daysLeft} days left this month</p>
              <div className="mt-5 h-4 rounded-full bg-white/15">
                <div className="h-4 w-[62%] rounded-full bg-[#d8ff69]" />
              </div>
              <div className="mt-5 rounded-3xl bg-white/10 p-3">
                <label className="text-xs uppercase tracking-widest text-white/55">
                  Quick add
                </label>
                <div className="mt-2 flex gap-2">
                  <input
                    value={quick}
                    onChange={(event) => setQuick(event.target.value)}
                    className="min-w-0 flex-1 rounded-2xl bg-white px-3 py-3 text-[#17201c] outline-none"
                    aria-label="Quick add expense"
                  />
                  <button className="rounded-2xl bg-[#d8ff69] px-4 font-black text-[#17201c]">
                    Add
                  </button>
                </div>
              </div>
            </div>

            <div className="rounded-[28px] bg-white p-5 shadow-xl shadow-black/5">
              <p className="text-sm font-semibold text-[#597366]">Expense log</p>
              <div className="mt-3 space-y-2">
                {expenses.map(([name, category, amount]) => (
                  <div key={name} className="flex items-center justify-between rounded-2xl bg-[#f6f4ef] p-3">
                    <div>
                      <p className="font-bold">{name}</p>
                      <p className="text-sm text-[#667266]">{category}</p>
                    </div>
                    <p className="font-black">₹{amount}</p>
                  </div>
                ))}
              </div>
              <label className="mt-4 flex items-center justify-between rounded-2xl bg-[#eef6ff] p-3 font-bold">
                Split with roommates
                <input
                  type="checkbox"
                  checked={split}
                  onChange={(event) => setSplit(event.target.checked)}
                  className="size-5"
                />
              </label>
            </div>
          </div>
        </section>

        <aside className="space-y-5">
          <div className="rounded-[28px] bg-white p-5 shadow-xl shadow-black/5">
            <p className="text-sm font-semibold text-[#597366]">
              Budget-friendly suggestions
            </p>
            <h2 className="mt-1 text-2xl font-black">Spend less nearby</h2>
            <div className="mt-4 space-y-3">
              <Suggestion title="Transport high" body="You spent ₹1,620 on rides. Try a bus pass or Namma Yatri before surge hours." />
              <Suggestion title="Food outside mess" body="7 delivery orders this month. Magicpin or EatSure may beat standard delivery pricing." />
              <Suggestion title="Subscription check" body="Two small subscriptions repeat next week. Keep Copilot, pause the inactive video plan." />
            </div>
          </div>

          <div className="rounded-[28px] bg-[#fff1c7] p-5">
            <p className="text-sm font-semibold text-[#695327]">Roommate settle-up</p>
            <h2 className="mt-1 text-2xl font-black">Aarav owes you ₹430</h2>
            <p className="mt-2 text-sm text-[#675834]">
              WiFi and shared groceries are tracked separately from your personal budget.
            </p>
            <button className="mt-4 w-full rounded-2xl bg-[#17201c] px-4 py-3 font-bold text-white">
              Open UPI payment
            </button>
          </div>

          <div className="rounded-[28px] bg-white p-5 shadow-xl shadow-black/5">
            <p className="text-sm font-semibold text-[#597366]">Savings goal</p>
            <h2 className="mt-1 text-2xl font-black">Laptop upgrade</h2>
            <div className="mt-4 h-3 rounded-full bg-[#ebe7db]">
              <div className="h-3 w-[44%] rounded-full bg-[#256cdd]" />
            </div>
            <p className="mt-2 text-sm text-[#667266]">₹13,200 saved of ₹30,000</p>
          </div>
        </aside>
      </section>
    </main>
  );
}

function Suggestion({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-3xl bg-[#f6f4ef] p-4">
      <p className="font-black">{title}</p>
      <p className="mt-1 text-sm text-[#667266]">{body}</p>
    </div>
  );
}
